
function [Rep DA]=MakeRepository(pop, Rep, F)
    
    global Settings;
    nRep = Settings.nRep;
    
    %Rep=[];    
%     if ~isempty(Rep)
%         DelSize=size(Rep,1)-floor(size(Rep,1)/4);
%         cds = [Rep.CD];
%         P=exp(-2*cds/sum(cds));
%         P=P/sum(P);
%         sel=[];
%         while numel(sel)~=DelSize && sum(cds)~=0
%              %pr=RouletteWheelSelection(P);
%              [~,pr]=min(cds);
%              sel=[sel pr];
%              sel=unique(sel);
%              %P(pr)=0;
%              %sel=[sel index];
%             cds(pr)=1000;
%         end
%         Rep(sel,:)=[]; 
%     end
    nGroup=numel(pop);    
    Temp_Rep=[];
                                       
    Temp_Rep=[Temp_Rep
        pop(F)];                
    
    delIndex=[];
    for i=1:numel(Rep)
        for j=1:numel(Temp_Rep)
            if(all(Rep(i).Cost==Temp_Rep(j).Cost))
                delIndex=[delIndex
                            j];
            end
        end
    end
    Temp_Rep(delIndex)=[];
    
    Temp_Rep=[Temp_Rep
        Rep];
    Costs=[Temp_Rep.Cost]; 
    for i=1:numel(Temp_Rep)
        y=Temp_Rep(i).Cost;
        res=find(all(Costs<=y) & any(Costs<y));
%         res=find((Costs(1,:)<=Temp_Rep(i).Cost(1) & Costs(2,:)<Temp_Rep(i).Cost(2))...
%             |(Costs(1,:)<Temp_Rep(i).Cost(1) & Costs(2,:)<=Temp_Rep(i).Cost(2)));
        if ~isempty(res)
            Temp_Rep(i).IsDominated=true;
        end        
        
    end
    Rep=Temp_Rep(~[Temp_Rep.IsDominated]);        

    DominatedIndex=1:numel(pop);
    DominatedIndex(F)=[];
    DA=pop(DominatedIndex);
    
    Rep=CalcCrowdingDistance(Rep);
    if numel(Rep)>nRep        
        DelSize=size(Rep,1)-nRep;
        cds = [Rep.CrowdingDistance];
        P=exp(cds/sum(cds));
        P=P/sum(P); 
        sel=[];
        while numel(sel)~=DelSize
            %index = RouletteWheelSelection(P);
            %sel=[sel index];
            %sel=unique(sel);
            %P(index)=0;    
            [~,index]=min(cds);
            sel=[sel index];
            cds(index)=1000;                
        end
        Rep(sel,:)=[];

    end            

end