
function Frep=DeleteRep(rep,nRep)

    cds = [rep.CrowdingDistance];
    [~,SortInds]=sort(cds,'descend');
    rep=rep(SortInds);
    rep(nRep+1:end)=[];
    Frep=rep;
    
end