function pop = Cloning( Rep, NC, N)
    
    Rep = CalcCrowdingDistance(Rep);
    cds= [Rep.CrowdingDistance];
    [~, ind]=sort(cds,'descend');
    Rep=Rep(ind);
    if NC>numel(Rep)
        Sel_Indiv=Rep;
    else
        Sel_Indiv = Rep(1:NC);
    end
           
    CrowdDis=[Rep.CrowdingDistance];
    if all(CrowdDis==inf)
        CrowdDis = ones(size(CrowdDis));
    else
        CrowdDis(CrowdDis==inf) = 2*max(CrowdDis(CrowdDis~=inf));
    end
    Cloned_Pop=[];
    for i=1:numel(Sel_Indiv)
       q=ceil(N*CrowdDis(i)/...
           sum(CrowdDis)); 
       copiedpop=repmat(Sel_Indiv(i),q,1);
       Cloned_Pop=[Cloned_Pop
                    copiedpop];
    end
    pop=Cloned_Pop(randi(numel(Cloned_Pop),1,N));
end

