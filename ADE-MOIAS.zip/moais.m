%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  Matlab Source Code for
%%% hybrid multi-objective immune algorithm with adaptive differential evolution
%%% https://doi.org/10.1016/j.cor.2015.04.003  

%%%%%%%%%%%  Programmed By: Yousef Abdi
%%%%%%%%%%%  E-mail: yousef.abdi@gmail.com, y.abdi@tabrizu.ac.ir
%%%%%%%%%%%  November 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
clear;
close all;

for Problem=[1 2 3 4 6]
    %% Problem Definition
    global Settings;

    prob=num2str(Problem);
    CostFunction=str2func(['@(x)  ZDT' prob '(x)']);  %Cost Function
    load(['Problem_PFs\ZDT' prob]);
    problemName=['ZDT' prob];
    
    VarMin=[]; VarMax=[];
    switch Problem
        case num2cell([1 2 3])
            nVar=30;
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;
        case 4
            nVar=10;
            VarMin(1)=0;
            VarMax(1)=1;
             VarMin(2:nVar)=-5;
             VarMax(2:nVar)=5;
        case 6
            nVar=10;
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;
    end

    nRep=100;
    Settings.nRep= nRep;
    Settings.nVar= nVar;
    Settings.CostFunction=CostFunction;

    VarSize=[1 nVar];

    VarRange=[VarMin VarMax];
    Rep=[];
    PrevRep=[];

    %% NSGA-II Parameters

    MaxIt=100;
    TotalRun=30;
    nPop=100;

    Fm=0.5;
    F_success=[];
    A=[];
    %% Initialization

    empty_individual.Position=[];
    empty_individual.Cost=[];
    empty_individual.CrowdingDistance=[];
    empty_individual.IsDominated=false;

    IGDs=zeros(MaxIt, TotalRun);
    HVs=zeros(MaxIt, TotalRun);
    for run=1:TotalRun

        pop=repmat(empty_individual,nPop,1);
        pop_child=[];
        for i=1:nPop
            pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
            pop(i).Cost=CostFunction(pop(i).Position);
            pop(i).IsDominated=false;
        end

        pop=DetermineDomination(pop);

        % Non-dominated 
        Rep=pop(~[pop.IsDominated]);
        DA=pop([pop.IsDominated]);

        % Calculate Crowding Distances
        Rep=CalcCrowdingDistance(Rep);

        NC = 20; % Antobodies have larger crowding distance
        %% Main Loop

        for it=1:MaxIt

            % Cloning
            pop = Cloning(Rep, NC, nPop);

            for i=1:nPop

                costs=[Rep.Cost];
                del_ind=find(all(pop(i).Cost==costs));
                Perm = 1:numel(Rep);
                
                if numel(Rep)>2
                    Perm(del_ind)=[];
                    r =  Perm(randperm(numel(Rep)-numel(del_ind),2));
                elseif numel(Rep)==2
                    r =  Perm(randperm(numel(Rep),2));
                else
                    r =  Perm(randperm(numel(Rep),1));
                    r(end+1)=r(end);
                end

                F= cauchy_dist(Fm, 0.1);
                v=Rep(r(1)).Position+F*(...
                        Rep(r(2)).Position-DA(randi(numel(DA))).Position);  

                y=zeros(1,nVar);
                j0=randi([1 nVar]);
                CR=0.55+1/pi*(atan((1-it/MaxIt-0.8)/0.1));
                for k=1:nVar
                    if k==j0 || rand<=CR
                        y(k)=v(k);
                    else
                        y(k)=pop(i).Position(k);
                    end
                end

                % Polynomial mutation
                [proM,disM] = deal(1,20);
                Site  = rand(1,nVar) < proM/nVar;
                mu    = rand(1,nVar);
                temp  = Site & mu<=0.5;
                y(temp) = y(temp)+(VarMax(temp)-VarMin(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                                  (1-(y(temp)-VarMin(temp))./(VarMax(temp)-VarMin(temp))).^(disM+1)).^(1/(disM+1))-1);
                temp = Site & mu>0.5; 
                y(temp) = y(temp)+(VarMax(temp)-VarMin(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                                  (1-(VarMax(temp)-y(temp))./(VarMax(temp)-VarMin(temp))).^(disM+1)).^(1/(disM+1)));

                for kk=1:nVar
                   if y(kk)< VarMin(kk)
                      y(kk)= VarMin(kk); 
                   end
                   if y(kk)> VarMax(kk)
                      y(kk)= VarMax(kk); 
                   end
                end
                y_cost = CostFunction(y); 
                empty_individual.Position=y;
                empty_individual.Cost=y_cost;
                pop_child=[pop_child 
                    empty_individual];
                if Dominates(y_cost, pop(i).Cost)
                    F_success=[F_success Fm];
                end
                if F_success > 0.1*nPop
                    Fm=mean(F_success);
                    F_success=[];            
                end
            end

            A=[Rep
                pop_child];
            pop_child=[];
            A=DetermineDomination(A);
            Rep=A(~[A.IsDominated]);
            DA=A([A.IsDominated]);
            % Calculate Crowding Distances
            Rep=CalcCrowdingDistance(Rep);
            if numel(Rep)>nRep
                Rep=DeleteRep(Rep,nRep);
            end
            IGDs(it,run)=IGD([Rep.Cost]',PF);
            HVs(it,run)=HV([Rep.Cost]',PF);

            % Plot Rep
            figure(1);
            PlotCosts2([Rep.Cost]);
            pause(0.0001);    

            disp(['Problem= ' num2str(Problem) ' : Run= ' num2str(run) ' : Iteraion ' num2str(it) ': Number of Repository Members = ' num2str(numel(Rep))]);

        end
        Rep_Whole{run}=Rep;
        save(['D://ADE-MOIAS_' problemName '_10000NFE.mat'],'HVs','IGDs', 'Rep', 'Rep_Whole');
    end    

end
